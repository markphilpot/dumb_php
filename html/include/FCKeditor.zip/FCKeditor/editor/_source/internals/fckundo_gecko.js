﻿var FCKUndo = new Object() ;

FCKUndo.SaveUndoStep = function()
{}